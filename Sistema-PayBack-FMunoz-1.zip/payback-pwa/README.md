# Sistema PAY BACK · F. Muñoz

Aplicación web progresiva (PWA) para calcular el **Período de Recuperación de la Inversión (PRI / Payback)** de un proyecto, con 4 módulos de cálculo, historial de proyectos y exportación a PDF y Excel.

## Contenido del paquete

```
payback-pwa/
├── index.html          → Pantalla principal (los 4 módulos + historial)
├── styles.css           → Estilos (paleta celeste-azul)
├── app.js                → Lógica de cálculo, historial y exportación
├── manifest.json         → Configuración de la PWA (nombre, ícono, colores)
└── service-worker.js     → Funcionamiento offline
```

Son **5 archivos sueltos**, sin subcarpetas — el ícono ya está incrustado dentro de `index.html` y `manifest.json`, así que puedes subirlos a cualquier hosting seleccionando los archivos uno por uno, sin preocuparte por preservar una carpeta `icons/`.

## Cómo publicarla

**GitHub Pages (recomendado, muy estable, no expira):**
1. Crea una cuenta gratis en [github.com](https://github.com) si no tienes
2. Crea un repositorio nuevo (público), por ejemplo `payback-app`
3. Dentro del repo: **Add file → Upload files**
4. Selecciona los 5 archivos de esta carpeta (puedes elegir varios a la vez desde el explorador del celular)
5. Confirma el "commit"
6. Ve a **Settings → Pages**, en "Branch" elige `main` y guarda
7. En un par de minutos te da una URL fija tipo `tu-usuario.github.io/payback-app`

**Cloudflare Pages / Workers:** también funciona, pero algunos operadores móviles en ciertos países bloquean o tienen fallas intermitentes con el dominio `*.workers.dev` / `*.pages.dev` (aparece como "ERR_FAILED" o "no se puede acceder"). Si te pasa eso de forma repetida, GitHub Pages (`github.io`) es una alternativa más confiable.

## Los 4 módulos

- **Módulo 1 — Flujos variados (fórmula):** `PRI = a + (Io − D) / F`.
- **Módulo 2 — Flujos constantes:** `PRI = Io / F`.
- **Módulo 3 — Método tabular:** tabla de flujo de caja, tabla acumulada y saldo pendiente, con interpolación del mes exacto de recuperación.
- **Módulo 4 — Comparar proyectos:** agrega varias alternativas (manual o importadas del historial) y la app resalta cuál se recupera en menor tiempo. Las comparaciones se pueden guardar y editar después desde el Historial.

## Historial

Cada cálculo se guarda con un nombre de proyecto, en el propio dispositivo (localStorage del navegador). Permite:
- Seleccionar todos los proyectos o solo algunos (con checkboxes) para **exportar a PDF o Excel**.
- Editar comparaciones guardadas del Módulo 4.
- Eliminar registros individuales o vaciar el historial completo.

> **Importante:** el historial vive en el navegador de ese dispositivo. Si limpias los datos del sitio en Chrome ("Borrar y restablecer"), cambias de navegador o de celular, el historial se pierde — no hay copia en la nube. Guarda tus PDFs/Excels exportados como respaldo si es información importante.

## Personalización

- Colores: variables CSS al inicio de `styles.css` (`--deep-blue`, `--celeste`, etc.).
- Ícono: está incrustado como base64 en `manifest.json` (campo `icons`) y en `index.html` (etiquetas `<link>` e `<img class="logo">`). Para cambiarlo, hay que regenerar esos base64 a partir de un nuevo PNG.
- Nombre de la app: campo `name`/`short_name` en `manifest.json`.
